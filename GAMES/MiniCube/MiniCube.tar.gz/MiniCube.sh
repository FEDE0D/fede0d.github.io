#!/bin/sh
MINICUBE="$(dirname "$0")"/MiniCube.jar
if [ -n "$JAVA_HOME" ]; then
  $JAVA_HOME/bin/java -jar "$MINICUBE" "$@"
else
  java -jar "$MINICUBE" "$@"
fi
