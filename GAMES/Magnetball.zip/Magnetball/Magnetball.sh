java -jar Magnetball.jar
