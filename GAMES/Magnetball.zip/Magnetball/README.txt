=Magnetball=

A game created for the 1GAM Challenge on January 2015.

The goal of the game is simple: touch the GREEN SQUARE to go the next level. Avoid the RED SQUARES.

Controls:	
	[ENTER] key to magnetize the ball.
	[R] key to reset the level.

Installation: You need to have Java installed on your machine (https://www.java.com)
	Windows / Mac: just double click "MagneticBall.jar".
	Linux: double click or use the MagneticBall.sh script to run the game.


Note: 
	I spend only a few days on the game as I was working on the engine first. The engine allows to edit the levels of the game in Tiled Editor (http://mapeditor.org) 	adding custom physics properties and entities to the world.
	This game is not finished and it currently has only 5 levels. It was more of a test to see what I could do using the engine I was creating. You can take a look at the files within the "maps" folder if you open them in Tiled Editor.

Have fun! - fede0d, Federico Pacheco


Contact:
	pixelated.gears@gmail.com
	http://twitter.com/fede0d
	http://fede0d.github.io


