This is an example Java project showing different aproches to procedural name generation.

More info: http://fede0d.github.io
