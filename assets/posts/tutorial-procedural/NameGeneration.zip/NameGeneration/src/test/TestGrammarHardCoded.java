package test;

import java.util.ArrayList;
import gramarbuilder.Atom;
import gramarbuilder.Operand;
import gramarbuilder.Option;
import gramarbuilder.Rule;

public class TestGrammarHardCoded {

	public static void main(String[] args) {

		Rule V = new Rule();
		V.addOption(new Option("a"));
		V.addOption(new Option("e"));
		V.addOption(new Option("i"));
		V.addOption(new Option("o"));
		V.addOption(new Option("u"));
		
		Rule Vacentuada = new Rule();
		Vacentuada.addOption(new Option("á"));
		Vacentuada.addOption(new Option("é"));
		Vacentuada.addOption(new Option("í"));
		Vacentuada.addOption(new Option("ó"));
		Vacentuada.addOption(new Option("ú"));
		
		Rule C = new Rule();
		C.addOption(new Option("b"));
		C.addOption(new Option("c"));
		C.addOption(new Option("d"));
		C.addOption(new Option("f"));
		C.addOption(new Option("g"));
		C.addOption(new Option("h"));
		C.addOption(new Option("j"));
//		C.addOption(new Option("k"));
		C.addOption(new Option("l"));
		C.addOption(new Option("m"));
		C.addOption(new Option("n"));
		C.addOption(new Option("p"));
//		C.addOption(new Option("q"));
		C.addOption(new Option("r"));
		C.addOption(new Option("s"));
		C.addOption(new Option("t"));
		C.addOption(new Option("v"));
//		C.addOption(new Option("w"));
//		C.addOption(new Option("x"));
//		C.addOption(new Option("y"));
		C.addOption(new Option("z"));
		
		Rule BEGIN = new Rule();
		BEGIN.addOption(new Option("a"));
		BEGIN.addOption(new Option("ra"));
		BEGIN.addOption(new Option("mo"));
		BEGIN.addOption(new Option("e"));
		BEGIN.addOption(new Option("var"));
		BEGIN.addOption(new Option("al"));
		
		Rule END = new Rule();
		END.addOption(new Option("co"));
		END.addOption(new Option("mez"));
		END.addOption(new Option("n"));
		END.addOption(new Option("ro"));
		END.addOption(new Option("rón"));
		END.addOption(new Option("rez"));
		
		Rule QU = new Rule();
		QU.addOption(new Option("que"));
		QU.addOption(new Option("qui"));
		QU.addOption(new Option("güe"));
		QU.addOption(new Option("güi"));
		QU.addOption(new Option("gua"));
		
		Option acentuado = new Option();
		acentuado.addOperand(BEGIN);
		acentuado.addOperand(C);
		acentuado.addOperand(V);
		acentuado.addOperand(C);
		acentuado.addOperand(Vacentuada);
		acentuado.addOperand(END);
		Option QUEGUI = new Option();
		QUEGUI.addOperand(C);
		QUEGUI.addOperand(V);
		QUEGUI.addOperand(QU);
		QUEGUI.addOperand(END);
		
		Rule NAME = new Rule();
		NAME.addOption(acentuado);
		NAME.addOption(QUEGUI);
		
		String n;
		for (int i=0;i<10;i++){
			n = NAME.resolve();
			n = n.substring(0, 1).toUpperCase()+n.substring(1);
			System.out.println(n);
		}
		
	}

}
