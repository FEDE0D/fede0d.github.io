package test;

import gramarbuilder.GrammarBuilder;
import gramarbuilder.Rule;

public class TestGrammar {

	public static void main(String[] args) {
		
		GrammarBuilder verbos = new GrammarBuilder("verbos.gr");
		Rule gerundio = verbos.getRule("ger");
		Rule indicativo = verbos.getRule("ind");
		Rule infinitivo = verbos.getRule("inf");
		Rule pasado3ra = verbos.getRule("3raPasadoSingular");
		Rule pasado3raPlural = verbos.getRule("3raPasadoPlural");
		
		GrammarBuilder fantasia = new GrammarBuilder("fantasia.gr");
		Rule runico = fantasia.getRule("runico");
		Rule elfico = fantasia.getRule("elfico");
		
		System.out.println("Cerca de la cima de la montaña "+capital(runico.resolve())+" vivía un grupo de enanos.");
		System.out.println("Ellos se hacían llamar los "+capital(runico.resolve())+" pues habían estado "+gerundio.resolve());
		System.out.println("sin rumbo por la tierra de "+capital(elfico.resolve())+" desde hacía mucho tiempo.");
		System.out.println("Los "+capital(elfico.resolve())+" "+pasado3raPlural.resolve()+" allí antes que ellos, aunque nunca llegaron a conocerse.");
		System.out.println("Un buen día el enano "+capital(runico.resolve())+" decidió bajar de la montaña y "+infinitivo.resolve()+" el Gran");
		System.out.println("Valle de "+capital(elfico.resolve())+".");
		
		System.out.println("Él "+pasado3ra.resolve()+" por las cuencas del río "+capital(runico.resolve())+" hasta las llanuras del ");
		System.out.println(capital(elfico.resolve())+" que se abrían debajo. Allí se encontró a si mismo "+gerundio.resolve());
		System.out.println("a través de la vegetación. Al llegar al otro lado una gente");
		System.out.println("extraña le cerró el paso.");
		System.out.println("El imaginó que "+indicativo.resolve()+" podría escapar...");
		
	}
	
	private static String capital(String w){
		return w.substring(0,1).toUpperCase()+w.substring(1);
	}
	
}
