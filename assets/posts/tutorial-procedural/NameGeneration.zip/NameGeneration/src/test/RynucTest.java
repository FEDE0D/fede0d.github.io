package test;

import gramarbuilder.GrammarBuilder;
import gramarbuilder.Rule;

public class RynucTest {

	
	public static void main(String[] args) {
		
		GrammarBuilder builder = new GrammarBuilder("rynuc.gr");
		Rule word = builder.getRule("RAIZ");
		
		for (int i=0;i<10;i++) System.out.println(word.resolve());

	}

}
