package test;

import gramarbuilder.GrammarBuilder;
import gramarbuilder.Rule;

public class TestBarbados {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GrammarBuilder builder = new GrammarBuilder("barbados.txt");
		Rule hombre = builder.getRule("HOMBRE");
		Rule mujer = builder.getRule("MUJER");
		for (int i=0; i<10;i++)
			System.out.println(mujer.resolve());
	}

}
