package test;

import algoritmos.Markov;

public class TestMarkov {

	public static void main(String[] args) {
		
//		Markov montania = new Markov("piedra.txt"); montania.setOrder(1);
//		Markov rey = new Markov("hombre.txt"); rey.setOrder(2);		
//		Markov mujer = new Markov("mujer.txt"); mujer.setOrder(3);
//		
//		System.out.println("Sobre la montaña "+montania.getNombre(4)+" vivia el rey "+rey.getNombre((int) (Math.random()*5)+5)+".");
//		System.out.println("Él estaba casado con la princesa "+mujer.getNombre((int) (Math.random()*2)+3)+" y con su hermana "+mujer.getNombre((int) (Math.random()*2)+3)+".");
		
		
		Markov test = new Markov("hombre.txt");
		test.setOrder(2);
		for (int i=0; i<10;i++) System.out.println(test.getNombre(8)+" ");
	}

}

