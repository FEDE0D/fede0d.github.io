package gramarbuilder;

public abstract class Operand {

	public abstract String resolve();
	
}
