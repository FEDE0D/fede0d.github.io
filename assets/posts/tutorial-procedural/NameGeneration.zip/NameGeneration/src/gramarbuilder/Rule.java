package gramarbuilder;

import java.util.ArrayList;
import java.util.Random;

public class Rule extends Operand{

	private ArrayList<Option> options;
	private Random random;
	
	public Rule(){
		random = new Random();
		options = new ArrayList<Option>();
	}
	
	public Rule(ArrayList<Option> options){
		random = new Random();
		this.options = options;
	}
	
	public String resolve() {
		if (!options.isEmpty()){
			int pos = random.nextInt(options.size());
			return options.get(pos).resolveOperation();
		}else
			return "";
	}

	public void addOption(Option o){
		options.add(o);
	}
	
}
