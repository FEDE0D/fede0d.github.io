package gramarbuilder;

import java.util.ArrayList;

public class Option {

	private ArrayList<Operand> operands;
	
	public Option(){
		operands = new ArrayList<Operand>();
	}
	
	public Option(String atom){//crea una option con un solo operando atomico
		operands = new ArrayList<Operand>();
		operands.add(new Atom(atom));
	}
	
	public Option(ArrayList<Operand> operands){
		this.operands = operands;
	}
	
	public String resolveOperation(){
		String result = "";
		for (int i=0;i<operands.size();i++)
			result+=operands.get(i).resolve();
		return result;
	}
	
	public void addOperand(Operand o){
		operands.add(o);
	}
	
}
