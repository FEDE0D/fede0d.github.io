package gramarbuilder;

import java.io.File;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GrammarBuilder {

	/*
	 * Esta clase genera una palabra aleatoriamente siguiendo reglas gramaticales
	 * especificadas desde un archivo.
	 * Idea: http://www.godpatterns.com/2005/09/name-generators-for-npcs-to-populate.html
	 * 
	 */
	
	private File file;
	private HashMap<String,Rule> rules;
	private HashMap<String,Option> options;
	private HashMap<String,Atom> atoms;
	
	public GrammarBuilder(String file){
		this.file = new File("reglas/"+file);
		load();
	}
	
	private void load(){
		rules = new HashMap<String,Rule>();
		options = new HashMap<String,Option>();
		atoms = new HashMap<String,Atom>();
		try{ 
			Scanner scaner = new Scanner(file);
			String line;
			Pattern operandsPattern = Pattern.compile("(\\[[.\\w\\s]+\\])|([\\w\\sáéíóúýâêîôûŷäëïöüÿàèìòù'-]*)");
			while (scaner.hasNextLine()){
				line = scaner.nextLine();
				if (!esComentario(line)){
					line = escape(line,"	");
					String[] partes = line.split("->");
					Rule rule;
					if (rules.containsKey(partes[0]))	rule = rules.get(partes[0]);
					else{rule = new Rule(); rules.put(partes[0], rule);}
					String[] options = partes[1].split("\\|");
					for (int i=0;i<options.length;i++){
						Option option = new Option();	this.options.put(options[i], option);
						rule.addOption(option);//las opciones se agregan sobreescribiendo porque siempre son unicas. Ej: Se crea una opcion A, que contiene un operando a. Cuando llegue otra operación A, está mal que se le agrege a esa misma operación un segundo operando a.
						Matcher m = operandsPattern.matcher(options[i]);
						while (m.find()){
							String operando = m.group();
							if (esRegla(operando)){
								Rule r;
								if (this.rules.containsKey(operando)) r = this.rules.get(operando);
								else{r = new Rule(); this.rules.put(operando, r);}
								option.addOperand(r);
							}else if (!operando.isEmpty()){
								Atom a;
								if (this.atoms.containsKey(operando))	a = this.atoms.get(operando);
								else{a = new Atom(operando); this.atoms.put(operando, a);}
								option.addOperand(a);
							}
						}
					}
					
				}
			}
			scaner.close();
		}catch(Exception e){e.printStackTrace(); System.exit(1);};
	}
	
	private boolean esComentario(String line){
		int i=0;
		while (i<line.length()&&(line.charAt(i)==' '||line.charAt(i)=='	')){
			i++;
		}
		return line.isEmpty()||line.charAt(i)=='#';
	}
	
	private String escape(String line,String chars){
		String result = "";
		for(int i=0;i<line.length();i++)
			if (chars.indexOf(line.charAt(i))==-1)
				result+=line.charAt(i);
		return result;
	}
	
	public String getWord(Rule rule){
		return rule.resolve();
	}
	
	public Rule getRule(String name){
		return rules.get("["+name+"]");
	}
	
	private boolean esRegla(String operando){
		return !operando.isEmpty()&&operando.matches("\\[[\\w\\s]+\\]");
	}
}
