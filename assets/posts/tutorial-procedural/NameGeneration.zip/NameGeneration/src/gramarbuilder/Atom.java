package gramarbuilder;

public class Atom extends Operand {

	private String value;
	
	public Atom(String value){
		this.value = value;
	}
	
	public String resolve() {
		return value;
	}

}
