package algoritmos;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class Markov {

	private long SEED; private Random random;
	private int ORDER = 1;
	protected String dataFile = "hombre.txt";
	
	protected HashMap<String, ArrayList<String>> DICTIONARY;
	protected ArrayList<String> COMIENZOS;
	
	
	public Markov(){
		SEED = System.currentTimeMillis(); random = new Random(SEED);
		loadStructure();
	}
	
	public Markov(String textInputFile) {
		SEED = System.currentTimeMillis(); random = new Random(SEED);
		dataFile = textInputFile;
		loadStructure();
	}
	
	protected void loadStructure(){
		DICTIONARY = new HashMap<String,ArrayList<String>>();
		COMIENZOS = new ArrayList<String>();
		try{
			File f = new File("diccionarios/"+dataFile);
			Scanner scaner = new Scanner(f);
			String palabra,parte;
			ArrayList<String> partes = new ArrayList<String>();
			while (scaner.hasNextLine()){
				palabra = scaner.next();
				partes = partir(palabra);
				if (!COMIENZOS.contains(partes.get(0))) COMIENZOS.add(partes.get(0));
				for (int i=0; i<partes.size(); i++){
					parte = partes.get(i);
					if (!DICTIONARY.containsKey(parte))
						DICTIONARY.put(parte, new ArrayList<String>());
					if (i+1<partes.size())
						DICTIONARY.get(parte).add(partes.get(i+1).substring(partes.get(i+1).length()-1));
				}
			}
			scaner.close();
		}catch(Exception e){e.printStackTrace(); System.out.println("ERROR: No se pudo generar el diccionario.");System.exit(1);};
	}

	public String getNombre(int size){
		String nombre = "";
		ArrayList<String> keys = new ArrayList<String>(DICTIONARY.keySet());
//		int pos = random.nextInt(keys.size());	String parte = keys.get(pos);
		int pos = random.nextInt(COMIENZOS.size());	String parte = COMIENZOS.get(pos);
		nombre+=parte;
		while (nombre.length()<size && !parte.equals("")){
			if (DICTIONARY.containsKey(parte)&&!DICTIONARY.get(parte).isEmpty()){
				int nextChar = random.nextInt(DICTIONARY.get(parte).size());
				nombre+=DICTIONARY.get(parte).get(nextChar);
				parte = parte.substring(parte.length()-ORDER+1)+DICTIONARY.get(parte).get(nextChar);
			}else
				parte="";
		}
		return capital(nombre);
	}
	
	private String capital(String s){
		return s.substring(0, 1).toUpperCase()+s.substring(1);
	}
	
	public long getSeed(){
		return SEED;
	}

	public void setSeed(long newSeed){
		SEED = newSeed;
		random = new Random(SEED);
	}
	
	public void setOrder(int newOrder){
		ORDER = newOrder;
		loadStructure();
	}
	
	protected ArrayList<String> partir(String p){
		ArrayList<String> partes = new ArrayList<String>();
		int i=0;
		partes.add(p.substring(i, Math.min(p.length(),i+ORDER )));	i++;	//para salvar las palabras con tamaño menor al orden
		while (i<=p.length()-ORDER){
			partes.add(p.substring(i, i+ORDER));	i++;
		}
		return partes;
	}

	public void print() {
		Iterator<String> it = DICTIONARY.keySet().iterator();
		int pos=0;
		while (it.hasNext()){
			String n = it.next();
			System.out.print(pos+" "+n+" -> "); pos++;
			for (int i=0;i<DICTIONARY.get(n).size();i++)
				System.out.print(DICTIONARY.get(n).get(i)+" ");
			System.out.println();
		}
	}
	
	public void printBeginnings(){
		Iterator<String> it = COMIENZOS.iterator();
		while (it.hasNext()){
			System.out.println(it.next());
		}
	}
}