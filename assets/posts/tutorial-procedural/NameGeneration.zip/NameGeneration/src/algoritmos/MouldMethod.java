package algoritmos;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class MouldMethod {

	/*
	 * Método por moldes. En lugar de almacenar la información de las cadenas Markov
	 * almaceno el patron VOCALES-CONSONANTES de cada palabra.
	 * Para generar una palabra se elige un patron (molde) al azar y se llena con las
	 * letras correspondientes.
	 * 
	 * Esto sirve bastante para crear palabras "realistas" de algún lenguaje solo con cambiar
	 * los datos de entrada y jugando con la probabilidad para cada caracter.
	 * 
	 * No sirve para nombres porque no respeta ninguna gramatica.
	 * Se podria mejorar usando cadenas Markov.
	 */
	
	private long SEED; private Random RANDOM;
	private String filename;
	private ArrayList<String> PATTERNS;
//	private String vocales = "aeiouäëïöüâêîôûáéíóúy";
	private String vocales = "aeiou";
	private String consonantes ="bcdfghjklmnpqrstvwxzy";
	private String otros = "' `";
	
	
	public MouldMethod(){
		this("hombre.txt");
	}
	
	public MouldMethod(String filename){
		SEED = System.currentTimeMillis();
		RANDOM = new Random(SEED);
		this.filename = filename;
		loadPatterns();
	}
	
	private void loadPatterns(){
		PATTERNS = new ArrayList<String>();
		File f = new File("diccionarios/"+filename);
		try{
			Scanner scaner = new Scanner(f);
			String word;
			while (scaner.hasNextLine()){
				word = scaner.nextLine();
				PATTERNS.add(toPattern(word));
			}
			scaner.close();
		}catch(Exception e){e.printStackTrace(); System.out.println("ERROR al cargar desde archivo."); System.exit(1);};
	}
	
	private String toPattern(String word){
		String pattern="";
		for (int i=0;i<word.length();i++){
			if (vocales.indexOf(word.charAt(i))!=-1) pattern+="V";
			else if (consonantes.indexOf(word.charAt(i))!=-1) pattern+="C";
			else pattern+="x";
		}
		return pattern;
	}
	
	public String getWord(){
		int patternPos = RANDOM.nextInt(PATTERNS.size());
		String pattern = PATTERNS.get(patternPos);
		String name = "";
		int charPos;
		for (int i=0;i<pattern.length();i++){
			if (pattern.charAt(i)=='V'){
				charPos = RANDOM.nextInt(vocales.length());
				name+=vocales.charAt(charPos);
			}else if (pattern.charAt(i)=='C'){
				charPos = RANDOM.nextInt(consonantes.length());
				name+=consonantes.charAt(charPos);
			}else{
				charPos = RANDOM.nextInt(otros.length());
				name+=otros.charAt(charPos);
			}
		}
		return name;
	}
	
	private String capital(String word){
		return word.substring(0, 1).toUpperCase()+word.substring(1);
	}
	
}
